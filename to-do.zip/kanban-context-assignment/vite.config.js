import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  // GitHub Pages와 로컬 정적 미리보기 모두에서 asset 경로가 깨지지 않게 설정합니다.
  base: './',
});
