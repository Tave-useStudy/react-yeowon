# Flowboard — React Context API Kanban Assignment

컴포넌트 구조 설계와 상태 관리 방식을 연습하기 위한 Kanban 보드입니다.
기본 구현은 **React Context API**이며, 선택 비교용 **Zustand store 예시**도 포함합니다.

## 구현 항목

- Board / Column / Card 계층 구조
- `children` 기반 Composition
- `Modal.Header / Modal.Body / Modal.Footer` Compound Component
- Context API 기반 전역 상태 공유
- props drilling 최소화
- `status="todo | doing | done"` explicit variant
- 카드 이동 버튼
- 카드 생성 / 상세 / 수정 / 삭제 Modal
- React Router 멀티 페이지
- 카드 상세 라우트
- localStorage 저장
- 선택 비교용 Zustand 구현
- GitHub Pages 자동 배포 workflow


## 설치 없이 바로 보는 HTML

`standalone-preview.html`은 React 빌드 없이 브라우저에서 바로 열 수 있는 기능형 미리보기입니다. 카드 추가/수정/삭제/단계 이동/localStorage 저장까지 동작합니다.

> 과제 제출의 메인 소스는 `src/`의 React Context API 구현이며, standalone 파일은 화면과 동작을 빠르게 확인하기 위한 보조 파일입니다.

## 실행

Node.js 22 권장.

```bash
npm install
npm run dev
```

브라우저에 표시된 Vite 주소로 접속합니다.

## 프로덕션 빌드

```bash
npm run build
npm run preview
```

빌드 결과는 `dist/`에 생성됩니다.

## GitHub에 올리기

```bash
git init
git add .
git commit -m "feat: complete kanban context assignment"
git branch -M main
git remote add origin https://github.com/사용자이름/저장소이름.git
git push -u origin main
```

## GitHub Pages

`.github/workflows/deploy.yml`이 포함되어 있습니다.

1. GitHub 저장소에 push
2. 저장소 `Settings → Pages`
3. Source를 **GitHub Actions**로 설정
4. main 브랜치에 push하면 자동 build/deploy

라우터는 `HashRouter`를 사용하므로 GitHub Pages 새로고침 404 문제를 피합니다.

## 프로젝트 구조

```text
src/
├─ App.jsx
├─ main.jsx
├─ context/
│  └─ KanbanContext.jsx
├─ data/
│  └─ initialCards.js
├─ components/
│  ├─ Board/
│  │  ├─ Board.jsx
│  │  ├─ Column.jsx
│  │  └─ Card.jsx
│  ├─ Modal/
│  │  ├─ Modal.jsx
│  │  └─ CardModal.jsx
│  └─ ui/
│     └─ Button.jsx
├─ pages/
│  ├─ BoardPage.jsx
│  ├─ CardDetailPage.jsx
│  └─ AboutPage.jsx
├─ alternatives/
│  └─ zustand/
└─ styles/
   └─ global.css
```

## 과제 설명 자료

`ASSIGNMENT_REPORT.md`에 각 agent-skill을 **문제 → 적용 rule → 결과** 형식으로 정리했습니다.
