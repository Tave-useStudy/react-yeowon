import { useEffect } from 'react';

function Modal({ children, onClose, label = '대화상자' }) {
  useEffect(() => {
    const handleKeyDown = (event) => {
      if (event.key === 'Escape') onClose();
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onClose]);

  return (
    <div className="modal-backdrop" onMouseDown={onClose}>
      <section
        className="modal"
        role="dialog"
        aria-modal="true"
        aria-label={label}
        onMouseDown={(event) => event.stopPropagation()}
      >
        {children}
      </section>
    </div>
  );
}

function ModalHeader({ children, onClose }) {
  return (
    <header className="modal__header">
      <div>{children}</div>
      <button className="modal__close" onClick={onClose} aria-label="닫기">
        ×
      </button>
    </header>
  );
}

function ModalBody({ children }) {
  return <div className="modal__body">{children}</div>;
}

function ModalFooter({ children }) {
  return <footer className="modal__footer">{children}</footer>;
}

Modal.Header = ModalHeader;
Modal.Body = ModalBody;
Modal.Footer = ModalFooter;

export default Modal;
