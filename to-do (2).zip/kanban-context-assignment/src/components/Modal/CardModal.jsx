import { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { useKanban } from '../../context/KanbanContext.jsx';
import Modal from './Modal.jsx';
import Button from '../ui/Button.jsx';

const EMPTY_FORM = {
  title: '',
  description: '',
  status: 'todo',
  priority: 'medium',
  tag: '',
};

function CardModal() {
  const {
    cards,
    modal,
    addCard,
    updateCard,
    deleteCard,
    closeModal,
  } = useKanban();

  const selectedCard = useMemo(
    () => cards.find((card) => card.id === modal.cardId) ?? null,
    [cards, modal.cardId],
  );

  const [form, setForm] = useState(EMPTY_FORM);

  useEffect(() => {
    if (modal.type === 'create') {
      setForm(EMPTY_FORM);
      return;
    }

    if (modal.type === 'detail' && selectedCard) {
      setForm({
        title: selectedCard.title,
        description: selectedCard.description,
        status: selectedCard.status,
        priority: selectedCard.priority,
        tag: selectedCard.tag,
      });
    }
  }, [modal.type, selectedCard]);

  if (!modal.type) return null;

  const isCreate = modal.type === 'create';
  const modalTitle = isCreate ? '새 카드 만들기' : '카드 상세 / 수정';

  const handleChange = (event) => {
    const { name, value } = event.target;
    setForm((current) => ({ ...current, [name]: value }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!form.title.trim()) return;

    if (isCreate) {
      addCard(form);
      return;
    }

    updateCard(selectedCard.id, {
      ...form,
      title: form.title.trim(),
      description: form.description.trim(),
      tag: form.tag.trim() || 'General',
    });
    closeModal();
  };

  return (
    <Modal onClose={closeModal} label={modalTitle}>
      <form onSubmit={handleSubmit}>
        <Modal.Header onClose={closeModal}>
          <span className="eyebrow">CARD EDITOR</span>
          <h2>{modalTitle}</h2>
        </Modal.Header>

        <Modal.Body>
          <div className="form-grid">
            <label className="form-field form-field--full">
              <span>제목</span>
              <input
                name="title"
                value={form.title}
                onChange={handleChange}
                placeholder="예: 발표 자료 정리"
                autoFocus
              />
            </label>

            <label className="form-field form-field--full">
              <span>설명</span>
              <textarea
                name="description"
                value={form.description}
                onChange={handleChange}
                rows="5"
                placeholder="카드에 대한 설명을 입력하세요."
              />
            </label>

            <label className="form-field">
              <span>상태</span>
              <select name="status" value={form.status} onChange={handleChange}>
                <option value="todo">할 일</option>
                <option value="doing">진행 중</option>
                <option value="done">완료</option>
              </select>
            </label>

            <label className="form-field">
              <span>우선순위</span>
              <select
                name="priority"
                value={form.priority}
                onChange={handleChange}
              >
                <option value="high">높음</option>
                <option value="medium">보통</option>
                <option value="low">낮음</option>
              </select>
            </label>

            <label className="form-field form-field--full">
              <span>태그</span>
              <input
                name="tag"
                value={form.tag}
                onChange={handleChange}
                placeholder="React, UI, Routing ..."
              />
            </label>
          </div>

          {!isCreate && selectedCard && (
            <Link className="modal__detail-link" to={`/card/${selectedCard.id}`} onClick={closeModal}>
              라우팅된 상세 페이지로 보기 →
            </Link>
          )}
        </Modal.Body>

        <Modal.Footer>
          {!isCreate && selectedCard ? (
            <Button
              variant="danger"
              type="button"
              onClick={() => deleteCard(selectedCard.id)}
            >
              삭제
            </Button>
          ) : (
            <span />
          )}

          <div className="modal__footer-actions">
            <Button type="button" variant="ghost" onClick={closeModal}>
              취소
            </Button>
            <Button type="submit" variant="primary">
              {isCreate ? '카드 추가' : '변경 저장'}
            </Button>
          </div>
        </Modal.Footer>
      </form>
    </Modal>
  );
}

export default CardModal;
