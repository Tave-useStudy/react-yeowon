import { Link } from 'react-router-dom';
import { useKanban } from '../../context/KanbanContext.jsx';
import Button from '../ui/Button.jsx';

const STATUS_FLOW = ['todo', 'doing', 'done'];
const STATUS_LABEL = {
  todo: '할 일',
  doing: '진행 중',
  done: '완료',
};
const PRIORITY_LABEL = {
  high: '높음',
  medium: '보통',
  low: '낮음',
};

function Card({ card }) {
  const { moveCard, openCardModal } = useKanban();
  const currentIndex = STATUS_FLOW.indexOf(card.status);
  const previousStatus = STATUS_FLOW[currentIndex - 1];
  const nextStatus = STATUS_FLOW[currentIndex + 1];

  return (
    <article className="task-card">
      <div className="task-card__topline">
        <span className={`priority priority--${card.priority}`}>
          {PRIORITY_LABEL[card.priority]}
        </span>
        <span className="task-card__tag">{card.tag}</span>
      </div>

      <button
        type="button"
        className="task-card__title-button"
        onClick={() => openCardModal(card.id)}
      >
        {card.title}
      </button>

      <p className="task-card__description">{card.description}</p>

      <div className="task-card__meta">
        <span>#{card.id}</span>
        <Link to={`/card/${card.id}`}>상세 페이지 ↗</Link>
      </div>

      <div className="task-card__actions">
        {previousStatus && (
          <Button
            variant="ghost"
            onClick={() => moveCard(card.id, previousStatus)}
            aria-label={`${card.title}을 ${STATUS_LABEL[previousStatus]} 단계로 이동`}
          >
            ← {STATUS_LABEL[previousStatus]}
          </Button>
        )}

        {nextStatus && (
          <Button
            variant="primary"
            onClick={() => moveCard(card.id, nextStatus)}
            aria-label={`${card.title}을 ${STATUS_LABEL[nextStatus]} 단계로 이동`}
          >
            {STATUS_LABEL[nextStatus]} →
          </Button>
        )}
      </div>
    </article>
  );
}

export default Card;
