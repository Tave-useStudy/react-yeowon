import { useMemo } from 'react';
import { useKanban } from '../../context/KanbanContext.jsx';
import Card from './Card.jsx';

function Column({ status, title, description, accent }) {
  const { cards } = useKanban();

  const columnCards = useMemo(
    () => cards.filter((card) => card.status === status),
    [cards, status],
  );

  return (
    <article className={`column column--${accent}`}>
      <header className="column__header">
        <div>
          <div className="column__title-row">
            <span className="column__dot" />
            <h2>{title}</h2>
            <span className="column__count">{columnCards.length}</span>
          </div>
          <p>{description}</p>
        </div>
      </header>

      <div className="column__list">
        {columnCards.length > 0 ? (
          columnCards.map((card) => <Card key={card.id} card={card} />)
        ) : (
          <div className="column__empty">이 단계의 카드가 없습니다.</div>
        )}
      </div>
    </article>
  );
}

export default Column;
