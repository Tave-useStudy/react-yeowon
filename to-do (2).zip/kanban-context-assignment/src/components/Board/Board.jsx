function Board({ children }) {
  return <section className="board">{children}</section>;
}

export default Board;
