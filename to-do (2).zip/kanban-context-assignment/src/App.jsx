import { NavLink, Route, Routes } from 'react-router-dom';
import BoardPage from './pages/BoardPage.jsx';
import CardDetailPage from './pages/CardDetailPage.jsx';
import AboutPage from './pages/AboutPage.jsx';
import CardModal from './components/Modal/CardModal.jsx';

function App() {
  return (
    <div className="app-shell">
      <header className="topbar">
        <NavLink className="brand" to="/" aria-label="Flowboard 홈">
          <span className="brand-mark">F</span>
          <span>
            <strong>Flowboard</strong>
            <small>React Kanban</small>
          </span>
        </NavLink>

        <nav className="main-nav" aria-label="주요 메뉴">
          <NavLink to="/" end>
            보드
          </NavLink>
          <NavLink to="/about">설계 설명</NavLink>
        </nav>
      </header>

      <Routes>
        <Route path="/" element={<BoardPage />} />
        <Route path="/card/:cardId" element={<CardDetailPage />} />
        <Route path="/about" element={<AboutPage />} />
        <Route path="*" element={<BoardPage />} />
      </Routes>

      <CardModal />
    </div>
  );
}

export default App;
