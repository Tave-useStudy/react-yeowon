# React 19 `use`로 Context 읽기

메인 구현은 학습 흐름이 익숙한 `useContext`를 사용합니다. React 19에서는 Context를 `use()`로도 읽을 수 있습니다.

```jsx
import { use } from 'react';

function Example() {
  const value = use(SomeContext);
  return <div>{value}</div>;
}
```

`use`는 일반 Hook과 달리 조건문 안에서도 호출할 수 있다는 차이가 있습니다.
