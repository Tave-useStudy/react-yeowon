import { createContext, useContext, useEffect, useMemo, useState } from 'react';
import { INITIAL_CARDS } from '../data/initialCards.js';

const STORAGE_KEY = 'flowboard-cards-v1';
const KanbanContext = createContext(null);

function readInitialCards() {
  if (typeof window === 'undefined') return INITIAL_CARDS;

  try {
    const saved = window.localStorage.getItem(STORAGE_KEY);
    if (!saved) return INITIAL_CARDS;

    const parsed = JSON.parse(saved);
    return Array.isArray(parsed) ? parsed : INITIAL_CARDS;
  } catch {
    return INITIAL_CARDS;
  }
}

export function KanbanProvider({ children }) {
  const [cards, setCards] = useState(readInitialCards);
  const [modal, setModal] = useState({ type: null, cardId: null });

  useEffect(() => {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(cards));
  }, [cards]);

  const addCard = (cardInput) => {
    const newCard = {
      id: Date.now(),
      title: cardInput.title.trim(),
      description: cardInput.description.trim(),
      status: cardInput.status,
      priority: cardInput.priority,
      tag: cardInput.tag.trim() || 'General',
    };

    setCards((current) => [newCard, ...current]);
    setModal({ type: null, cardId: null });
  };

  const updateCard = (cardId, updates) => {
    setCards((current) =>
      current.map((card) =>
        card.id === cardId ? { ...card, ...updates } : card,
      ),
    );
  };

  const deleteCard = (cardId) => {
    setCards((current) => current.filter((card) => card.id !== cardId));
    setModal({ type: null, cardId: null });
  };

  const moveCard = (cardId, nextStatus) => {
    updateCard(cardId, { status: nextStatus });
  };

  const openCreateModal = () => {
    setModal({ type: 'create', cardId: null });
  };

  const openCardModal = (cardId) => {
    setModal({ type: 'detail', cardId });
  };

  const closeModal = () => {
    setModal({ type: null, cardId: null });
  };

  const resetBoard = () => {
    setCards(INITIAL_CARDS);
    setModal({ type: null, cardId: null });
  };

  const value = useMemo(
    () => ({
      cards,
      modal,
      addCard,
      updateCard,
      deleteCard,
      moveCard,
      openCreateModal,
      openCardModal,
      closeModal,
      resetBoard,
    }),
    [cards, modal],
  );

  return <KanbanContext value={value}>{children}</KanbanContext>;
}

export function useKanban() {
  const context = useContext(KanbanContext);

  if (!context) {
    throw new Error('useKanban은 KanbanProvider 내부에서 사용해야 합니다.');
  }

  return context;
}
