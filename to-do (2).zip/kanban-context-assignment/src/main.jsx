import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { HashRouter } from 'react-router-dom';
import App from './App.jsx';
import { KanbanProvider } from './context/KanbanContext.jsx';
import './styles/global.css';

createRoot(document.getElementById('root')).render(
  <StrictMode>
    <HashRouter>
      <KanbanProvider>
        <App />
      </KanbanProvider>
    </HashRouter>
  </StrictMode>,
);
