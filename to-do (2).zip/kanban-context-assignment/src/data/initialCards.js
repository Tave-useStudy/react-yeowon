export const BOARD_COLUMNS = [
  {
    status: 'todo',
    title: '할 일',
    description: '아직 시작하지 않은 작업',
    accent: 'violet',
  },
  {
    status: 'doing',
    title: '진행 중',
    description: '현재 집중하고 있는 작업',
    accent: 'blue',
  },
  {
    status: 'done',
    title: '완료',
    description: '끝낸 작업',
    accent: 'green',
  },
];

export const INITIAL_CARDS = [
  {
    id: 101,
    title: 'Context API 복습',
    description: 'createContext, Provider, useContext의 흐름을 예제로 정리한다.',
    status: 'todo',
    priority: 'high',
    tag: 'React',
  },
  {
    id: 102,
    title: 'Compound Modal 설계',
    description: 'Modal.Header / Body / Footer를 조합 가능한 구조로 분리한다.',
    status: 'todo',
    priority: 'medium',
    tag: 'Architecture',
  },
  {
    id: 103,
    title: 'Kanban 카드 이동',
    description: '버튼 클릭으로 todo → doing → done 상태를 변경한다.',
    status: 'doing',
    priority: 'high',
    tag: 'Interaction',
  },
  {
    id: 104,
    title: 'React Router 연결',
    description: '보드, 카드 상세, 설계 설명 페이지를 라우팅한다.',
    status: 'doing',
    priority: 'low',
    tag: 'Routing',
  },
  {
    id: 105,
    title: '컴포넌트 역할 분리',
    description: 'Board / Column / Card가 각각 한 가지 책임을 갖도록 나눈다.',
    status: 'done',
    priority: 'medium',
    tag: 'Structure',
  },
];
