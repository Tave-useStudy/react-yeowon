# Zustand 비교용 구현

메인 앱은 과제 요구대로 Context API를 사용합니다.
이 폴더는 같은 상태 로직을 Zustand store로 옮긴 비교 예시입니다.

## Context 버전

```jsx
<KanbanProvider>
  <App />
</KanbanProvider>

const { cards, moveCard } = useKanban();
```

## Zustand 버전

```jsx
const cards = useKanbanStore((state) => state.cards);
const moveCard = useKanbanStore((state) => state.moveCard);
```

차이는 Provider를 직접 구성하지 않고 store에서 필요한 조각을 selector로 구독한다는 점입니다.
