import { create } from 'zustand';
import { INITIAL_CARDS } from '../../data/initialCards.js';

// 선택 비교용 예시입니다. 실제 앱은 과제 조건대로 Context API를 사용합니다.
// Context 버전의 Provider + useContext를 Zustand store로 바꾸면 어떤 차이가 나는지 비교할 수 있습니다.
export const useKanbanStore = create((set) => ({
  cards: INITIAL_CARDS,

  addCard: (cardInput) =>
    set((state) => ({
      cards: [
        {
          id: Date.now(),
          ...cardInput,
          title: cardInput.title.trim(),
          description: cardInput.description.trim(),
          tag: cardInput.tag.trim() || 'General',
        },
        ...state.cards,
      ],
    })),

  updateCard: (cardId, updates) =>
    set((state) => ({
      cards: state.cards.map((card) =>
        card.id === cardId ? { ...card, ...updates } : card,
      ),
    })),

  deleteCard: (cardId) =>
    set((state) => ({
      cards: state.cards.filter((card) => card.id !== cardId),
    })),

  moveCard: (cardId, nextStatus) =>
    set((state) => ({
      cards: state.cards.map((card) =>
        card.id === cardId ? { ...card, status: nextStatus } : card,
      ),
    })),
}));
