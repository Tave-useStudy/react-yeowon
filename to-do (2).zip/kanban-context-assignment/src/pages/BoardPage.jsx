import Board from '../components/Board/Board.jsx';
import Column from '../components/Board/Column.jsx';
import Button from '../components/ui/Button.jsx';
import { useKanban } from '../context/KanbanContext.jsx';
import { BOARD_COLUMNS } from '../data/initialCards.js';

function BoardPage() {
  const { cards, openCreateModal, resetBoard } = useKanban();
  const completedCount = cards.filter((card) => card.status === 'done').length;
  const progress = cards.length === 0 ? 0 : Math.round((completedCount / cards.length) * 100);

  return (
    <main className="page page--board">
      <section className="hero-panel">
        <div>
          <span className="eyebrow">WEEKLY PROJECT</span>
          <h1>작업의 흐름을 한눈에.</h1>
          <p>
            Context API로 상태를 공유하고, Composition 패턴으로 조립한 React Kanban Board입니다.
          </p>
        </div>

        <div className="hero-actions">
          <Button variant="ghost" onClick={resetBoard}>
            샘플 초기화
          </Button>
          <Button variant="primary" onClick={openCreateModal}>
            + 새 카드
          </Button>
        </div>
      </section>

      <section className="board-summary" aria-label="보드 요약">
        <div>
          <span>전체 카드</span>
          <strong>{cards.length}</strong>
        </div>
        <div>
          <span>완료 카드</span>
          <strong>{completedCount}</strong>
        </div>
        <div className="progress-block">
          <div>
            <span>완료율</span>
            <strong>{progress}%</strong>
          </div>
          <div className="progress-track" aria-label={`완료율 ${progress}%`}>
            <span style={{ width: `${progress}%` }} />
          </div>
        </div>
      </section>

      <Board>
        {BOARD_COLUMNS.map((column) => (
          <Column key={column.status} {...column} />
        ))}
      </Board>

    </main>
  );
}

export default BoardPage;
