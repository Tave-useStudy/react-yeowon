const ITEMS = [
  {
    number: '01',
    title: 'Context API',
    body: 'Board → Column → Card로 상태를 계속 넘기는 대신 KanbanProvider에서 상태와 액션을 공유합니다.',
  },
  {
    number: '02',
    title: 'Composition',
    body: 'Board는 children을 받아 내부 구성에 관여하지 않습니다. 사용하는 쪽에서 Column을 조합합니다.',
  },
  {
    number: '03',
    title: 'Compound Modal',
    body: 'Modal.Header, Modal.Body, Modal.Footer를 관련 컴포넌트 묶음으로 설계해 재사용성과 가독성을 높였습니다.',
  },
  {
    number: '04',
    title: 'Explicit variants',
    body: 'isTodo / isDoing / isDone 같은 boolean 조합 대신 status="todo | doing | done"처럼 한 가지 명확한 값으로 상태를 표현합니다.',
  },
];

function AboutPage() {
  return (
    <main className="page about-page">
      <section className="about-hero">
        <span className="eyebrow">ARCHITECTURE NOTES</span>
        <h1>기능보다 구조를 설명할 수 있는 코드.</h1>
        <p>
          이번 과제의 핵심인 컴포넌트 책임 분리, Context 상태 공유, Composition 패턴을 코드 구조에 직접 반영했습니다.
        </p>
      </section>

      <section className="architecture-grid">
        {ITEMS.map((item) => (
          <article key={item.number} className="architecture-card">
            <span>{item.number}</span>
            <h2>{item.title}</h2>
            <p>{item.body}</p>
          </article>
        ))}
      </section>

      <section className="flow-diagram">
        <span className="eyebrow">STATE FLOW</span>
        <div className="flow-row">
          <div>KanbanProvider</div>
          <span>→</span>
          <div>useKanban()</div>
          <span>→</span>
          <div>Column / Card / Modal</div>
        </div>
      </section>
    </main>
  );
}

export default AboutPage;
