import { Link, useParams } from 'react-router-dom';
import { useKanban } from '../context/KanbanContext.jsx';
import Button from '../components/ui/Button.jsx';

const STATUS_LABEL = {
  todo: '할 일',
  doing: '진행 중',
  done: '완료',
};

const PRIORITY_LABEL = {
  high: '높음',
  medium: '보통',
  low: '낮음',
};

function CardDetailPage() {
  const { cardId } = useParams();
  const { cards, openCardModal } = useKanban();
  const card = cards.find((item) => item.id === Number(cardId));

  if (!card) {
    return (
      <main className="page detail-page">
        <div className="detail-card empty-state">
          <span className="eyebrow">NOT FOUND</span>
          <h1>카드를 찾을 수 없습니다.</h1>
          <p>삭제되었거나 존재하지 않는 카드입니다.</p>
          <Link className="text-link" to="/">← 보드로 돌아가기</Link>
        </div>
      </main>
    );
  }

  return (
    <main className="page detail-page">
      <Link className="text-link" to="/">← 보드로 돌아가기</Link>

      <article className="detail-card">
        <div className="detail-card__header">
          <div>
            <span className="eyebrow">CARD #{card.id}</span>
            <h1>{card.title}</h1>
          </div>
          <Button variant="primary" onClick={() => openCardModal(card.id)}>
            수정하기
          </Button>
        </div>

        <p className="detail-card__description">{card.description}</p>

        <dl className="detail-list">
          <div>
            <dt>상태</dt>
            <dd>{STATUS_LABEL[card.status]}</dd>
          </div>
          <div>
            <dt>우선순위</dt>
            <dd>{PRIORITY_LABEL[card.priority]}</dd>
          </div>
          <div>
            <dt>태그</dt>
            <dd>{card.tag}</dd>
          </div>
        </dl>
      </article>
    </main>
  );
}

export default CardDetailPage;
