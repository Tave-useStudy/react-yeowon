# Flowboard — React Context API Kanban Assignment

이번 ZIP에는 **바로 열리는 실제 웹사이트**와 **React 원본 소스**가 둘 다 들어 있습니다.

## 가장 먼저 확인할 것

### 1) 설치 없이 실제 웹사이트 보기

압축을 푼 뒤 아래 파일을 더블클릭하세요.

```text
index.html
```

또는 더 눈에 띄는 아래 파일을 열어도 같은 웹사이트로 이동합니다.

```text
OPEN_WEBSITE.html
```

`index.html`은 더 이상 빈 Vite 진입점이 아니라 완성된 Kanban 웹사이트입니다.
카드 추가, 수정, 삭제, 단계 이동, localStorage 저장, 보드/설계 설명 화면 이동이 모두 동작합니다.

## 2) React 과제 원본 실행

React/Vite 버전의 진입 파일은 `react-entry.html`로 분리했습니다.

```bash
npm install
npm run dev
```

실행하면 React Context API로 구현한 앱이 열립니다.

## 주요 구조

```text
src/
├─ App.jsx
├─ context/
│  └─ KanbanContext.jsx
├─ data/
│  └─ initialCards.js
├─ pages/
│  ├─ BoardPage.jsx
│  ├─ CardDetailPage.jsx
│  └─ AboutPage.jsx
├─ components/
│  ├─ Board/
│  │  ├─ Board.jsx
│  │  ├─ Column.jsx
│  │  └─ Card.jsx
│  └─ Modal/
│     ├─ Modal.jsx
│     └─ CardModal.jsx
└─ styles/
   └─ global.css
```

## 과제 요구사항 반영

- Context API 우선 구현
- Board / Column / Card 역할 분리
- children 기반 Composition
- Modal Compound Component
- props drilling 최소화
- boolean props 대신 명시적인 `status` variant
- 카드 이동: todo → doing → done
- 카드 상세 / 수정 / 삭제 Modal
- React Router 기반 멀티 페이지 React 소스
- 상태와 UI 분리
- 선택 비교용 Zustand 예시 포함

## GitHub Pages

저장소에 그대로 push한 뒤 GitHub의 **Settings → Pages → Source → GitHub Actions**를 선택하면 `.github/workflows/deploy.yml`이 동작합니다.

배포된 사이트의 기본 `/`에서는 바로 열리는 `index.html` 웹사이트를 볼 수 있고, 빌드 결과에는 React 번들도 함께 생성됩니다.

## 파일 설명

- `index.html`: 설치 없이 바로 실행 가능한 실제 웹사이트
- `OPEN_WEBSITE.html`: `index.html`을 바로 여는 바로가기
- `react-entry.html`: Vite/React용 진입점
- `src/`: 과제 평가용 React 원본 코드
- `ASSIGNMENT_REPORT.md`: 문제 → 적용 rule → 결과 정리
