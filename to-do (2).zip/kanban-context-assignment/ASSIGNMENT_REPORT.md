# 과제 적용 정리: 문제 → 적용 rule → 결과

## 1. Props drilling

**문제**  
Board → Column → Card 깊이로 `cards`, `moveCard`, `openModal` 같은 값을 계속 전달하면 중간 컴포넌트가 사용하지 않는 props까지 전달해야 합니다.

**적용 rule**  
- `state-lift-state`
- `state-context-interface`
- `state-decouple-implementation`

**결과**  
공유 상태를 `KanbanProvider`로 올리고 `useKanban()` 인터페이스를 통해 필요한 컴포넌트가 직접 접근합니다. UI 컴포넌트는 상태 저장 방식 자체를 알 필요가 줄어듭니다.

---

## 2. Boolean props 남용

**문제**

```jsx
<Card isTodo isDoing={false} isDone={false} />
```

상태가 늘수록 prop 조합이 복잡하고, `isTodo`와 `isDone`이 동시에 true인 잘못된 조합도 가능해집니다.

**적용 rule**  
- `architecture-avoid-boolean-props`
- `patterns-explicit-variants`

**결과**

```jsx
<Card status="todo" />
```

`status` 하나로 `todo | doing | done` 중 한 값만 갖도록 의미를 명확하게 했습니다.

---

## 3. Board의 내부 구조 고정

**문제**  
Board가 Column 개수와 내용을 직접 결정하면 다른 화면에서 재사용하기 어렵습니다.

**적용 rule**  
- `patterns-children-over-render-props`

**결과**

```jsx
<Board>
  <Column status="todo" />
  <Column status="doing" />
  <Column status="done" />
</Board>
```

Board는 레이아웃만 책임지고 내부 콘텐츠는 `children`으로 조합합니다.

---

## 4. Modal props 증가

**문제**  
`title`, `body`, `footer`, 버튼 여부 등을 모두 Modal props로 만들면 Modal API가 커집니다.

**적용 rule**  
- `architecture-compound-components`
- `patterns-children-over-render-props`

**결과**

```jsx
<Modal>
  <Modal.Header />
  <Modal.Body />
  <Modal.Footer />
</Modal>
```

관련 컴포넌트를 하나의 명확한 인터페이스로 묶고 필요한 부분만 조합합니다.

---

## 5. 상태와 UI 결합

**문제**  
Card 컴포넌트 안에서 전체 카드 배열을 직접 수정하는 로직까지 관리하면 UI 책임과 데이터 변경 책임이 섞입니다.

**적용 rule**  
- `state-decouple-implementation`
- `state-context-interface`

**결과**  
상태 변경은 `KanbanProvider`의 `moveCard`, `updateCard`, `deleteCard`에 두고, Card는 사용자의 의도를 액션 함수로 전달합니다.

---

## 6. React 19 ref 전달

이번 구현에서는 `forwardRef`가 필요한 구조를 만들지 않았습니다. React 19에서는 필요한 경우에도 `ref`를 일반 prop처럼 전달할 수 있으므로 불필요한 `forwardRef` 패턴을 추가하지 않았습니다.

**적용 rule**
- `react19-no-forwardref`

---

# Context API → Zustand 비교

## Context

```jsx
<KanbanProvider>
  <App />
</KanbanProvider>

const { cards, moveCard } = useKanban();
```

- React 기본 기능
- Provider와 Context interface를 직접 설계
- 상태 공유 구조를 학습하기 좋음

## Zustand

```jsx
const cards = useKanbanStore((state) => state.cards);
const moveCard = useKanbanStore((state) => state.moveCard);
```

- Provider 없이 store를 직접 구독 가능
- 필요한 상태 조각을 selector로 선택 가능
- 코드량이 줄고 store 중심 구조가 명확해짐

선택 비교 코드는 `src/alternatives/zustand/`에 포함했습니다.
